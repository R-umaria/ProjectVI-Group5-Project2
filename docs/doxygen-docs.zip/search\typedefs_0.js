var searchData=
[
  ['sockethandle_0',['SocketHandle',['../namespace_fleet_telemetry.html#a8a811fa1fd60448e9b3e38bbffd2ecf6',1,'FleetTelemetry']]]
];
