var searchData=
[
  ['flightcount_0',['FlightCount',['../struct_fleet_telemetry_1_1_flight_statistics.html#a0cf25c3e93a943901d469fa63c96f56c',1,'FleetTelemetry::FlightStatistics']]],
  ['fuelconsumed_1',['FuelConsumed',['../struct_fleet_telemetry_1_1_flight_statistics.html#a8bd333580a47cca8440a586f9c434ad2',1,'FleetTelemetry::FlightStatistics']]],
  ['fuelquantity_2',['FuelQuantity',['../struct_fleet_telemetry_1_1_telemetry_record.html#a7b262577695190161f59e6b024e1725b',1,'FleetTelemetry::TelemetryRecord']]]
];
