var searchData=
[
  ['flightstate_0',['FlightState',['../struct_fleet_telemetry_1_1_telemetry_processor_1_1_flight_state.html',1,'FleetTelemetry::TelemetryProcessor']]],
  ['flightstatistics_1',['FlightStatistics',['../struct_fleet_telemetry_1_1_flight_statistics.html',1,'FleetTelemetry']]]
];
