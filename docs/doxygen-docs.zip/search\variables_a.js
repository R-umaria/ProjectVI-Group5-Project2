var searchData=
[
  ['overallaveragefuelconsumptionperhour_0',['OverallAverageFuelConsumptionPerHour',['../struct_fleet_telemetry_1_1_flight_statistics.html#ae7e99ef651cd59bfcf20ee0baa531ed0',1,'FleetTelemetry::FlightStatistics']]]
];
