var searchData=
[
  ['endfuel_0',['EndFuel',['../struct_fleet_telemetry_1_1_flight_statistics.html#abb44ddc9fe940028fce7a455560fed4e',1,'FleetTelemetry::FlightStatistics']]],
  ['endtimestamp_1',['EndTimestamp',['../struct_fleet_telemetry_1_1_flight_statistics.html#ab4d9300bfd3cdb6c93bc97251f74678c',1,'FleetTelemetry::FlightStatistics']]]
];
