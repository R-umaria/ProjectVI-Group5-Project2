var searchData=
[
  ['getactivestatisticssnapshot_0',['GetActiveStatisticsSnapshot',['../class_fleet_telemetry_1_1_aircraft_session_manager.html#ae010022469f547218ba7caae382725ac',1,'FleetTelemetry::AircraftSessionManager']]],
  ['getcurrentstatistics_1',['GetCurrentStatistics',['../class_fleet_telemetry_1_1_telemetry_processor.html#a6a91eec8ff7c62c4503a1aae53e45fc0',1,'FleetTelemetry::TelemetryProcessor']]],
  ['getlasterrorstring_2',['GetLastErrorString',['../namespace_fleet_telemetry_1_1_network.html#a6530f0c719032eca4f3990d2058fa309',1,'FleetTelemetry::Network']]]
];
