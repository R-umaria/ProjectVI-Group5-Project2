var searchData=
[
  ['samplecount_0',['SampleCount',['../struct_fleet_telemetry_1_1_flight_statistics.html#af9ae225ffd0deec5c7e843ffc9eee9ba',1,'FleetTelemetry::FlightStatistics']]],
  ['sendintervalms_1',['SendIntervalMs',['../struct_fleet_telemetry_1_1_client_config.html#ae0fc29daaf17a22271e109a4c8f193d1',1,'FleetTelemetry::ClientConfig::SendIntervalMs'],['../_client_app_8cpp.html#a747786148616ee1fc2c4279310f99304',1,'SendIntervalMs:&#160;ClientApp.cpp']]],
  ['serverip_2',['ServerIp',['../struct_fleet_telemetry_1_1_client_config.html#a3fb13c04fb76341661eae487b46dc595',1,'FleetTelemetry::ClientConfig::ServerIp'],['../_client_app_8cpp.html#ac12e4e47ed0793debc69f567df869510',1,'ServerIp:&#160;ClientApp.cpp']]],
  ['serverport_3',['ServerPort',['../struct_fleet_telemetry_1_1_client_config.html#a98244fc67ed4eb31a3405362e950e8e4',1,'FleetTelemetry::ClientConfig::ServerPort'],['../_client_app_8cpp.html#ac07f72fb0144988faf99f36493c1958a',1,'ServerPort:&#160;ClientApp.cpp']]],
  ['startfuel_4',['StartFuel',['../struct_fleet_telemetry_1_1_flight_statistics.html#a2fa9ed6c1aa5b04e5d24b14863716b48',1,'FleetTelemetry::FlightStatistics']]],
  ['starttimestamp_5',['StartTimestamp',['../struct_fleet_telemetry_1_1_flight_statistics.html#aaa2171f309231f5ca345a1de78043039',1,'FleetTelemetry::FlightStatistics']]],
  ['statistics_6',['Statistics',['../struct_fleet_telemetry_1_1_telemetry_processor_1_1_flight_state.html#a0b5bf55babc701eafae252826d1f4bbf',1,'FleetTelemetry::TelemetryProcessor::FlightState']]],
  ['statsfile_7',['StatsFile',['../struct_fleet_telemetry_1_1_server_config.html#a355124f43aa2a44e5f890ec93a90c722',1,'FleetTelemetry::ServerConfig::StatsFile'],['../_server_app_8cpp.html#a73e07c2d0d3d04d55022a33edabf6d8d',1,'StatsFile:&#160;ServerApp.cpp']]]
];
