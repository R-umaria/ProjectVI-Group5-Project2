var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuw~",
  1: "acflpst",
  2: "f",
  3: "acflmnpstu",
  4: "abcdefgilmoprstw~",
  5: "abcefghilmopst",
  6: "s",
  7: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Pages"
};

