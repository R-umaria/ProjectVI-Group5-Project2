var searchData=
[
  ['clientname_0',['ClientName',['../struct_fleet_telemetry_1_1_client_config.html#abe34b945f4599199acff4b2558756571',1,'FleetTelemetry::ClientConfig']]],
  ['completed_1',['Completed',['../struct_fleet_telemetry_1_1_flight_statistics.html#a1c37e1c18e282a3094d11b318c82d4fe',1,'FleetTelemetry::FlightStatistics']]],
  ['cumulativefuelconsumed_2',['CumulativeFuelConsumed',['../struct_fleet_telemetry_1_1_flight_statistics.html#a7a22848bb2e3ddce536001a4c5d2bd15',1,'FleetTelemetry::FlightStatistics']]],
  ['cumulativetotalseconds_3',['CumulativeTotalSeconds',['../struct_fleet_telemetry_1_1_flight_statistics.html#a92c3500a491febe81c9ff0ce378c8898',1,'FleetTelemetry::FlightStatistics']]],
  ['currentfuelconsumptionpersecond_4',['CurrentFuelConsumptionPerSecond',['../struct_fleet_telemetry_1_1_flight_statistics.html#a9f789b7a79e20655ca7e7c16973ac8d6',1,'FleetTelemetry::FlightStatistics']]]
];
