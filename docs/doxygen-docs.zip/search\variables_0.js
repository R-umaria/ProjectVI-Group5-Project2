var searchData=
[
  ['aircraftid_0',['AircraftId',['../struct_fleet_telemetry_1_1_flight_statistics.html#a83587401b29f21c8ca52fc306a8da608',1,'FleetTelemetry::FlightStatistics::AircraftId'],['../struct_fleet_telemetry_1_1_telemetry_record.html#a1f28fea28eb393e2a31c01711fa5271b',1,'FleetTelemetry::TelemetryRecord::AircraftId'],['../_client_app_8cpp.html#a02d2ddf690ae03ca8cbc341ddbc00898',1,'AircraftId:&#160;ClientApp.cpp']]],
  ['aircraftidprovidedbyuser_1',['AircraftIdProvidedByUser',['../_client_app_8cpp.html#a2a74e718ef38dbb4282c39f135fb87a0',1,'ClientApp.cpp']]],
  ['averagefuelconsumptionperhour_2',['AverageFuelConsumptionPerHour',['../struct_fleet_telemetry_1_1_flight_statistics.html#a7973f0d9e23ef43ab94e9952f8b432fc',1,'FleetTelemetry::FlightStatistics']]],
  ['averagefuelconsumptionpersecond_3',['AverageFuelConsumptionPerSecond',['../struct_fleet_telemetry_1_1_flight_statistics.html#a78fabd03aae0e5e723d0277c7653a4ee',1,'FleetTelemetry::FlightStatistics']]]
];
