var searchData=
[
  ['open_0',['Open',['../class_fleet_telemetry_1_1_telemetry_reader.html#a0f98c517b458a1768a5a33e7e6ab1e10',1,'FleetTelemetry::TelemetryReader']]],
  ['operator_3d_1',['operator=',['../class_fleet_telemetry_1_1_client_socket.html#ac27f6d95e0764d280195c04e7bb5efef',1,'FleetTelemetry::ClientSocket::operator=()'],['../class_fleet_telemetry_1_1_client_handler.html#aa38b2ae5dd05e91510cf87cb0bb2cda3',1,'FleetTelemetry::ClientHandler::operator=()'],['../class_fleet_telemetry_1_1_server_listener.html#ae407147fa9ca3982da6ecbe394946891',1,'FleetTelemetry::ServerListener::operator=()']]],
  ['overallaveragefuelconsumptionperhour_2',['OverallAverageFuelConsumptionPerHour',['../struct_fleet_telemetry_1_1_flight_statistics.html#ae7e99ef651cd59bfcf20ee0baa531ed0',1,'FleetTelemetry::FlightStatistics']]]
];
