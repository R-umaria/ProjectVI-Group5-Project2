var searchData=
[
  ['hasprevioussample_0',['HasPreviousSample',['../struct_fleet_telemetry_1_1_telemetry_processor_1_1_flight_state.html#afe09984f7e17de52ae6201975144e20c',1,'FleetTelemetry::TelemetryProcessor::FlightState']]]
];
