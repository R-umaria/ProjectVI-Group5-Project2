var searchData=
[
  ['g_5fnetworkmutex_0',['g_networkMutex',['../namespace_fleet_telemetry_1_1_network.html#a9bfc188fcfe17e233a4351a2639a14e7',1,'FleetTelemetry::Network']]],
  ['g_5fnetworkusercount_1',['g_networkUserCount',['../namespace_fleet_telemetry_1_1_network.html#a56a3350ab688a1af977d5da271a73389',1,'FleetTelemetry::Network']]],
  ['getactivestatisticssnapshot_2',['GetActiveStatisticsSnapshot',['../class_fleet_telemetry_1_1_aircraft_session_manager.html#ae010022469f547218ba7caae382725ac',1,'FleetTelemetry::AircraftSessionManager']]],
  ['getcurrentstatistics_3',['GetCurrentStatistics',['../class_fleet_telemetry_1_1_telemetry_processor.html#a6a91eec8ff7c62c4503a1aae53e45fc0',1,'FleetTelemetry::TelemetryProcessor']]],
  ['getlasterrorstring_4',['GetLastErrorString',['../namespace_fleet_telemetry_1_1_network.html#a6530f0c719032eca4f3990d2058fa309',1,'FleetTelemetry::Network']]]
];
