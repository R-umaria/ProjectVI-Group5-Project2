var searchData=
[
  ['deserialize_0',['Deserialize',['../class_fleet_telemetry_1_1_packet.html#ae07f8f2b8ce52a524a4d1bbfdce19009',1,'FleetTelemetry::Packet']]],
  ['disconnect_1',['Disconnect',['../class_fleet_telemetry_1_1_client_socket.html#acd64bc9854660c6c56f869246cad38bf',1,'FleetTelemetry::ClientSocket']]]
];
